
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse:collapse; border:1px solid #ddd;background-color: #f5f5f5">
	
	 
	<tr>
		<td align="left" style="margin:auto; padding:15px"><p style="font-size:14px; color:#656565; font-family:'Gotham Medium', Arial; margin:0; padding-top:5px; padding-bottom:5px;line-height: 25px;">Name : {{$details['name']}}  <br>
		
		Phone : {{$details['phone']}} <br>
		Visa  : {{$details['visa']}}<br>
		Email : {{$details['email']}}<br>
		
		Message : {{$details['message']}}
		
		</p>
		</td>
	</tr>
	</table>
