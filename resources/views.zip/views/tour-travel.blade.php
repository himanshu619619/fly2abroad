@include('header');


<section class="wide-60 about-section about-2" id="about-2">
        <div class="container">

            <div class="row d-flex align-items-center">
                <div class="col-md-6">
                    <div class="about-img about-2-img text-center mb-40">
                        <img class="img-fluid" src="{{asset('public/images/image-03.png')}}"
                            alt="about-image" />
                        
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-2-txt pc-20 mb-40">
                        <span class='section-id id-color'></span>
                        <h3 class='h3-lg darkblue-color'>Consultations for prospective immigrants</h3>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-genderless"></i></div>
                            <p>An magnis nulla dolor sapien augue erat iaculis purus tempor magna ipsum vitae purus
                                primis pretium ligula rutrum luctus blandit porta justo integer. Feugiat a primis
                                ultrice ligula </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-genderless"></i></div>
                            <p>Nemo ipsam egestas volute turpis dolores and aliquam quaerat sodales sapien undo pretium
                                purus ligula a tempus ipsum undo auctor a mauris lectus ipsum blandit egestas magna
                                ligula </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-genderless"></i></div>
                            <p>An magnis nulla dolor sapien augue erat iaculis purus tempor magna ipsum vitae purus
                                primis pretium ligula rutrum luctus blandit porta justo integer. Feugiat a primis
                                ultrice ligula </p>
                        </div>
                    </div>
                </div> <!-- END ABOUT TEXT	-->
            </div> <!-- End row -->
        </div> <!-- End container -->
    </section>



    <section class="bg-lightgrey pt-100 about-section about-4 bg-tra-city" id="about-4">
        <div class="container">

            <div class="row d-flex flex-row-reverse align-items-center">
                <div class="col-lg-5 col-xl-5 offset-xl-1">
                    <div class="about-img about-4-img text-center ">
                        <img class="img-fluid" src="{{asset('public/images/image-04.png')}}"
                            alt="about-image" />
                    </div>
                </div>
                <div class="col-lg-7 col-xl-6">
                    <div class="about-4-txt pc-20 mb-40">
                        <span class='section-id id-color'>Professional Advisors</span>
                        <h3 class='h3-lg darkblue-color'>We provide the best consulting services in the industry since
                            2009</h3>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-genderless"></i></div>
                            <p>An magnis nulla dolor sapien augue erat iaculis purus tempor magna ipsum vitae purus
                                primis pretium ligula rutrum luctus blandit porta justo integer. Feugiat a primis
                                ultrice ligula</p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-genderless"></i></div>
                            <p>Quaerat sodales sapien undo euismod risus auctor egestas augue mauri undo viverra tortor
                                sapien sodales sapien and vitae donec gravida donec enim blandit ipsum at porta justo
                                integer </p>
                        </div>
                        <a class='btn btn-arrow btn-md btn-primary' href='tel:+1(778) 929 9866'><span>Call: +1(778) 929 9866<i
                                    class='fas fa-arrow-right'></i></span></a>
                    </div>
                </div> <!-- END ABOUT TEXT	-->
            </div> <!-- End row -->
        </div> <!-- End container -->
    </section>


@include('footer');